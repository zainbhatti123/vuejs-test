<template>
  <div class="text-center">
    <div v-if="gettedItems.length > 0">
      <div class="text-center">
        <h4>Items</h4>
      </div>
      <table
        class="table mt-4 table-bordered text-start"
        aria-describedby="items"
        v-if="!loading"
      >
        <thead>
          <th>ID</th>
          <th>Name</th>
          <th>Status</th>
          <th>Actions</th>
        </thead>
        <tbody>
          <tr v-for="(item, index) in gettedItems" :key="index">
            <td>{{ index + 1 }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.completed }}</td>
            <td>
              <button
                class="btn btn-primary btn-sm"
                :disabled="editMode"
                @click="emits('edit', item), (editMode = true)"
              >
                <span class="material-icons fs-6"> edit </span>
              </button>
              <button
                class="btn btn-danger ms-2 btn-sm"
                @click="handleDelete(item, index)"
                :disabled="editMode"
              >
                <span class="material-icons fs-6"> delete </span>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <Loader v-else />
    </div>

    <div v-else>
      <h4 class="text-danger">No Items Found</h4>
    </div>
  </div>
</template>

<script setup>
import { ref } from "@vue/reactivity";
import { onMounted, watch } from "@vue/runtime-core";
import { getItem, deleteItem } from "../api";
import Loader from './Loader.vue';

const props = defineProps({
  item: Object,
});

const emits = defineEmits(["edit"]);

const editMode = ref(false);
const loading = ref(false);
const gettedItems = ref([]);

const getitemsFromApi = () => {
  loading.value = true;
  getItem().then(({ data }) => {
    loading.value = false;
    gettedItems.value = data;
  });
};

onMounted(() => {
  getitemsFromApi();
});

const handleDelete = (item, i) => {
  gettedItems.value.splice(i, 1);
  deleteItem(item.id);
};

watch(props, () => {
  editMode.value = false;
  getitemsFromApi();
});
</script>

<style>
th,
.table tbody td {
  padding: 1rem;
  vertical-align: middle;
}

table th:nth-of-type(2) {
  width: 80%;
}
</style>