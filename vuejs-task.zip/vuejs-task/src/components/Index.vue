<template>
  <div class="container">
    <div class="row">
      <div class="col-12 py-5">
        <form action="" @submit="handleSubmit($event)">
          <div class="d-flex align-items-center mb-5">
            <label for="item">Item:</label>
            <input
              type="text"
              class="form-control mx-3"
              placeholder="Enter Name"
              v-model="name"
            />

            <label for="complete" class="flex-shrink-0 pe-4">
              <input type="checkbox" id="complete" v-model="completed" />
              Completed</label
            >
            <button class="btn btn-primary flex-shrink-0" :disabled="!name">
              {{ editMode ? "Update" : "Add" }}
            </button>
          </div>
        </form>
        <Items @edit="handleEdit" :item="sendItem" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "@vue/reactivity";
import { addItem, updateItem } from "../api";
import Items from "./Items.vue";

const name = ref("");
const completed = ref(false);
const sendItem = ref(null);
const editMode = ref(false);
const idForUpdate = ref("");

const handleEdit = (item) => {
  editMode.value = true;
  name.value = item.name;
  completed.value = item.completed;
  idForUpdate.value = item.id;
};

const handleSubmit = (e) => {
  e.preventDefault();
  const item = {
    name: name.value,
    completed: completed.value,
    id: idForUpdate.value,
  };

  if (editMode.value) {
    updateItem(item, idForUpdate.value).then(() => {
      sendItem.value = item;
    });
  } else {
    addItem(item).then(() => {
      sendItem.value = item;
    });
  }
  name.value = "";
  completed.value = false;
  editMode.value = false;
};
</script>

<style scoped>
</style>
