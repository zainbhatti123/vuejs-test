<template>
    <table class="table loader-table">
        <thead>
            <th><span></span></th>
            <th><span></span></th>
            <th><span></span></th>
            <th><span></span></th>
        </thead>
        <tbody>
            <tr>
                <td><span></span></td>
                <td><span></span></td>
                <td><span></span></td>
                <td><span></span></td>
            </tr>
            <tr>
                <td><span></span></td>
                <td><span></span></td>
                <td><span></span></td>
                <td><span></span></td>
            </tr>
        </tbody>
    </table>
</template>

<style scoped>
table th:nth-of-type(2){
    width: 80%;
}
</style>