<script setup>
import Index from './components/Index.vue';
</script>

<template>
  <Index />
</template>

