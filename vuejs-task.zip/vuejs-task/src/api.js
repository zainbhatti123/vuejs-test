import axios from "axios";

const baseUrl = 'http://localhost:3004/'

export const getItem = async () => {
    const response = await axios.get(`${baseUrl}items`);
    return response;
}
export const addItem = async (data) => {
    const response = await axios.post(`${baseUrl}items`, data);
    return response;
}

export const deleteItem = async (id) => {
    const response = await axios.delete(`${baseUrl}items/${id}`);
    return response;
}

export const updateItem = async (data, id) => {
    const response = await axios.put(`${baseUrl}items/${id}`, data);
    return response;
}